import React, { Component, PropTypes } from 'react';
// import Phaser from 'phaser';
import { DragDropContext } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';
import range from 'lodash/range';
import { connect } from 'react-redux';


// @connect((state) => {return {game: state.game.toJS(), score: state.score}})

@DragDropContext(HTML5Backend)
export class Game extends Component {

  turnCard = () => {
    const { dispatch } = this.props;
    dispatch(ActionCreators.turnCard());
  }

  moveCards = (cards, where) => {
    const { dispatch } = this.props;
    dispatch(ActionCreators.moveCard(cards, where));
  }

  render() {
    const { game, score } = this.props;
    const { moveCards, turnCard } = this;
    console.log(score);
    return (
      <div style = ({
        width: 800,
        height: 600,
        backgroudColor: '#4CAF60',
        padding: 10
      })>
      <div className="" >
        goodbye

      </div>
    );
  }

}

Game.propTypes = {
  game: PropTypes.arrayOf(PropTypes.shape({
    name: PropTypes.string.isRequired,
  })),
};

export default Game;
