import React, { PropTypes, Component } from 'react';
import { connect } from 'react-redux';

import { Game } from '../../components/Game/Game';

import { getGames } from '../../GameReducer';
import { fetchGame } from '../../GameActions';

export class GamePage extends Component {
  componentDidMount() {
    this.props.dispatch(fetchGame());
  }

  render() {
    return (
      <div>
        Hello Game!
        {/* <Game game={this.props.game} /> */}
      </div>
    );
  }
}

//GamePage.need = [() => { return getGames(); }];

function mapStateToProps(state) {
  return {
    game: getGames(state),
  };
}

GamePage.propTypes = {
  game: PropTypes.arrayOf(PropTypes.shape({
    name: PropTypes.string.isRequired,
  })).isRequired,
  dispatch: PropTypes.func.isRequired,
};

GamePage.contextTypes = {
  router: React.PropTypes.object,
};

export default connect(mapStateToProps)(GamePage);
